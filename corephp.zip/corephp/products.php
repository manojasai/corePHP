<?php
 session_start(); 
 ?>
<html>
	<head>
		<title>Test</title>
	</head>
	<body>
		<a href="add.php" >Add Product</a> 
		<table border="1">
			<thead>
				<tr>
					<th>SL</th>
					<th>Name</th>
					<th>Description</th>
					<th>Price</th>
					<th>Image</th>
					<th>Created</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
				include "db.php";
				$res=$mysqli->query("SELECT * FROM product ");
				//print_r($row=$res->fetch_assoc()); 
				$sl=1;
				while($row=$res->fetch_assoc()){
				
				?>
				<tr>
					<td><?php echo $sl; ?></td>
					<td><?php echo $row['name']; ?></td>
					<td><?php echo $row['description']; ?></td>
					<td><?php echo $row['price']; ?></td>
					<td><img src="uploads/<?php echo $row['image']; ?>" width="30" height="30" /></td>
					<td><?php echo $row['created_at']; ?></td>
					<th><a href="edit.php?id=<?php echo $row['id']; ?>" >Edit</a>  <a href="delete.php?id=<?php echo $row['id']; ?>" >Delete</a></th>
				</tr>
				<?php $sl++; } ?>
			</tbody>
		
		</table>
			<a href="logout.php" >Logout</a>					
	</body>
</html>