<?php
 session_start(); 
 ?>
<html>
	<head>
		<title>Test</title>
	</head>
	<body>
		
		<form name="form" action="edit_submit.php" method="POST" enctype="multipart/form-data">
			<?php
				include "db.php";
				$id=$_GET['id'];
				$res=$mysqli->query("SELECT * FROM product where id='$id'");
				while($row=$res->fetch_assoc()){
			?>
				Name:<input type="text" name="name" value="<?php echo $row['name']; ?>" required="required">
				Description:<input type="text" name="description" value="<?php echo $row['description']; ?>" required="required">
				Price:<input type="text" name="price" value="<?php echo $row['price']; ?>" required="required">
				Image:<input type="file" name="image" >
				<input type="hidden" name="id"  value="<?php echo $row['id']; ?>">
				<input type="submit" name="submit"  value="Submit">
			<?php } ?>
						
		</form>
								
	</body>
</html>