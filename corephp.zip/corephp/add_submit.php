<?php
session_start();
include "db.php";
if(!empty($_POST["submit"])){
    $name=$_POST["name"];
    $description=$_POST["description"];
    $price=$_POST["price"];
	
	if(isset($_FILES['image'])){
		$file_name = $_FILES['image']['name'];
		move_uploaded_file($_FILES['image']['tmp_name'],"uploads/".$file_name);
	}
	else{
		$file_name ="";
	}
	$mysqli->query("INSERT into product (id, name, description, price,image  ) VALUES (NULL, '$name', '$description', '$price', '$file_name')");

}
header("location:products.php");
?>
