
<?php
session_start();
include "db.php";
$id=$_GET['id'];

$mysqli->query("DELETE from product where id='$id'");

header("location:products.php");
?>
						
		