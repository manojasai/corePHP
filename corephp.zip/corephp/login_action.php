<?php
session_start();
include "db.php";
if(!empty($_POST["submit"])){
    $username=$_POST["username"];
    $password=md5($_POST['password']);
    $res=$mysqli->query("SELECT * FROM login WHERE username='$username' and password='$password'");
	$row=$res->fetch_assoc();
	if(count($row)>0){
        $_SESSION['username']=$username;
        header("location:products.php");
    }
    else{
	
	 $_SESSION['message']="<span style='color:red;'>Username or Password is invalid</span>"; 
	
        header("location:index.php");
    }
}
?>
