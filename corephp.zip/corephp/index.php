<?php
 session_start(); 
 ?>
<html>
	<head>
		<title>Test</title>
	</head>
	<body>
		
		<form name="login-form" action="login_action.php" method="POST" >
			<input type="text" name="username" id="username" placeholder="Username" required="required">
									
			<input type="password" name="password" id="password" placeholder="Password" required="required">
			
			<input type="submit" name="submit" id="login-submit" value="Submit">
						
		</form>
		<?php
			if(isset($_SESSION['message'])){
				echo $_SESSION['message'];
			}
			unset( $_SESSION['message'] );
		?>
								
	</body>
</html>