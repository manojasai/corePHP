<?php
 session_start(); 
 ?>
<html>
	<head>
		<title>Test</title>
	</head>
	<body>
		
		<form name="form" action="add_submit.php" method="POST" enctype="multipart/form-data">
			
				Name:<input type="text" name="name"  required="required">
				Description:<input type="text" name="description"  required="required">
				Price:<input type="text" name="price" required="required">
				Image:<input type="file" name="image" required="required">
				<input type="submit" name="submit"  value="Submit">
						
		</form>
								
	</body>
</html>